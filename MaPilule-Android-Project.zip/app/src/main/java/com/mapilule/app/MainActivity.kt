package com.mapilule.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.mapilule.app.ui.screens.*
import com.mapilule.app.ui.theme.MaPiluleTheme
import com.mapilule.app.ui.viewmodel.MainViewModel

enum class ScreenState {
    MAIN,
    CALENDAR,
    SETTINGS,
    CHANGE_PIN
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Rappels quotidiens autorisés", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Sécurité stricte : FLAG_SECURE empêche la capture d'écran et masque l'aperçu dans le multitâche
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // Verrouillage automatique quand l'application passe en arrière-plan
        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                viewModel.lockApp()
            }
        })

        // Demande de permission de notification pour Android 13+ (jusqu'à Android 16)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }

            MaPiluleTheme(darkTheme = isDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val isPinConfigured by viewModel.isPinConfigured.collectAsState()
                    val isLocked by viewModel.isLocked.collectAsState()

                    var currentScreen by remember { mutableStateOf(ScreenState.MAIN) }

                    when {
                        // Premier démarrage : Configuration initiale du code NIP
                        !isPinConfigured -> {
                            PinScreen(
                                isSetupMode = true,
                                onPinSuccess = { newPin ->
                                    viewModel.createInitialPin(newPin)
                                    Toast.makeText(this@MainActivity, "NIP configuré avec succès", Toast.LENGTH_SHORT).show()
                                },
                                onVerifyPin = { false }
                            )
                        }

                        // Application verrouillée : Écran de saisie du NIP
                        isLocked -> {
                            PinScreen(
                                isSetupMode = false,
                                onPinSuccess = {},
                                onVerifyPin = { pin -> viewModel.unlockWithPin(pin) }
                            )
                        }

                        // Écrans de l'application déverrouillée
                        else -> {
                            when (currentScreen) {
                                ScreenState.MAIN -> {
                                    val todayDose by viewModel.todayDose.collectAsState()
                                    val past7Days by viewModel.past7Days.collectAsState()

                                    MainScreen(
                                        todayFormatted = viewModel.todayFormatted,
                                        todayDose = todayDose,
                                        past7Days = past7Days,
                                        onConfirmPill = { viewModel.confirmPillTaken() },
                                        onCancelConfirmation = { viewModel.cancelTodayConfirmation() },
                                        onOpenCalendar = { currentScreen = ScreenState.CALENDAR },
                                        onOpenSettings = { currentScreen = ScreenState.SETTINGS }
                                    )
                                }

                                ScreenState.CALENDAR -> {
                                    val allDoses by viewModel.allDoses.collectAsState()
                                    CalendarScreen(
                                        doses = allDoses,
                                        onBack = { currentScreen = ScreenState.MAIN }
                                    )
                                }

                                ScreenState.SETTINGS -> {
                                    val reminderHour by viewModel.reminderHour.collectAsState()
                                    val reminderMinute by viewModel.reminderMinute.collectAsState()
                                    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()

                                    SettingsScreen(
                                        reminderHour = reminderHour,
                                        reminderMinute = reminderMinute,
                                        notificationsEnabled = notificationsEnabled,
                                        themeMode = themeMode,
                                        onBack = { currentScreen = ScreenState.MAIN },
                                        onUpdateReminderTime = { h, m -> viewModel.setReminderTime(h, m) },
                                        onToggleNotifications = { enabled -> viewModel.setNotificationsEnabled(enabled) },
                                        onUpdateTheme = { mode -> viewModel.setThemeMode(mode) },
                                        onChangePinRequest = { currentScreen = ScreenState.CHANGE_PIN },
                                        onResetDataRequest = {
                                            viewModel.lockApp()
                                        }
                                    )
                                }

                                ScreenState.CHANGE_PIN -> {
                                    PinScreen(
                                        isSetupMode = true,
                                        onPinSuccess = { newPin ->
                                            viewModel.createInitialPin(newPin)
                                            Toast.makeText(this@MainActivity, "Nouveau code NIP enregistré", Toast.LENGTH_SHORT).show()
                                            currentScreen = ScreenState.SETTINGS
                                        },
                                        onVerifyPin = { false }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
