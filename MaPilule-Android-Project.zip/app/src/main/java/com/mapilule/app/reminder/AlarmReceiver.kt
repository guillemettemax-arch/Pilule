package com.mapilule.app.reminder

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import com.mapilule.app.MainActivity
import com.mapilule.app.MaPiluleApp
import com.mapilule.app.R
import com.mapilule.app.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "AlarmReceiver"
        private const val NOTIFICATION_ID = 2001
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.CANADA_FRENCH).format(Date())
                val db = AppDatabase.getDatabase(context)
                val doseRecord = db.doseDao().getDoseSync(todayIso)

                if (doseRecord != null && doseRecord.taken) {
                    // RÈGLE STRICTE : Si la dose est déjà confirmée, NE RIEN ENVOYER
                    Log.d(TAG, "Prise déjà confirmée aujourd'hui. Aucun rappel envoyé.")
                } else {
                    // Prise non confirmée : envoyer la notification discrète
                    showReminderNotification(context)
                }

                // Toujours reprogrammer pour le lendemain
                ReminderScheduler.scheduleDailyReminder(context)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showReminderNotification(context: Context) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MaPiluleApp.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_pill)
            .setContentTitle(context.getString(R.string.notification_title))
            .setContentText(context.getString(R.string.notification_message))
            .setStyle(NotificationCompat.BigTextStyle().bigText(context.getString(R.string.notification_message)))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
