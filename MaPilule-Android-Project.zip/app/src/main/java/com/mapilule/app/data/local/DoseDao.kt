package com.mapilule.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DoseDao {

    @Query("SELECT * FROM dose_records WHERE date_iso = :dateIso LIMIT 1")
    fun getDoseFlow(dateIso: String): Flow<DoseEntity?>

    @Query("SELECT * FROM dose_records WHERE date_iso = :dateIso LIMIT 1")
    suspend fun getDoseSync(dateIso: String): DoseEntity?

    @Query("SELECT * FROM dose_records WHERE date_iso >= :startDate AND date_iso <= :endDate ORDER BY date_iso ASC")
    fun getDosesBetween(startDate: String, endDate: String): Flow<List<DoseEntity>>

    @Query("SELECT * FROM dose_records ORDER BY date_iso DESC")
    fun getAllDoses(): Flow<List<DoseEntity>>

    @Query("SELECT * FROM dose_records ORDER BY date_iso DESC")
    suspend fun getAllDosesSync(): List<DoseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(dose: DoseEntity)

    @Query("DELETE FROM dose_records WHERE date_iso = :dateIso")
    suspend fun deleteDose(dateIso: String)

    @Query("DELETE FROM dose_records")
    suspend fun clearAll()
}
